package com.example.test2dushyant;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;

public class HelloController {

    public Label welcomeText;
    public TextField password;
    public TextField username;

    @FXML
    protected void onHelloButtonClick() {

        String uname = username.getText();
        String upass = password.getText();

        if (uname.equals("") && password.equals("")) {
            welcomeText.setText("please give username/password");
        }
         else {

            String jdbcUrl = "jdbc:mysql://localhost:3306/intellij";
            String dbUser = "root";
            String dbPassword = "";

            try (Connection connection = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword)) {
                // Execute a SQL query to retrieve data from the database
                String query = "SELECT * FROM user WHERE `email`='" + uname + "' AND `password`='" + upass + "' ";
                Statement statement = connection.createStatement();
                ResultSet resultSet = statement.executeQuery(query);

                // Populate the table with data from the database
                if (resultSet.next()) {

                    try {
                        Parent secondScene = FXMLLoader.load(getClass().getResource("dashboard.fxml"));

                        Stage secondStage = new Stage();
                        secondStage.setTitle("Dashboard");
                        secondStage.setScene(new Scene(secondScene));
                        Stage firstSceneStage = (Stage) welcomeText.getScene().getWindow();

                        firstSceneStage.close();


                        secondStage.show();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    welcomeText.setText("Invalid username/password");
                }
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }
}